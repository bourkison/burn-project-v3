/* eslint-disable */
const AWS = require('aws-sdk');
/* eslint-enable */
const s3 = new AWS.S3({});

/* eslint-disable */
exports.handler = function (event, context) {
/* eslint-enable */

/*
Function that triggers on the output bucket.

event.Records contains an array of S3 records that you can take action on.
*/

};